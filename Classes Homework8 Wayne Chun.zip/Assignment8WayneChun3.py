# -------------------------------------------------
# Title: Classes with Python
# Dev:   Wayne Chun
# Date:  15 May 2018
# ChangeLog: (Who, When, What)
#   WChun, 15 May 2018 Creation of Class using existing
#        code by Randal Root
# -------------------------------------------------
#                Classes
#
# This program is a example of using Classes to take existing
# code and group (data and processing code).  It is rewritten from
# a base code provided by Randal Root to:
#
#  We are asked to:
#   1)	Create and test a new Python file using the following code:
#   2) Create one or more classes to store and process Product data using the code previous code.

'''
#Data
objFile = None #File Handle
strUserInput = None #A string which holds user input

#Processing
def WriteProductUserInput(File):
  try:
    print("Type in a Product Id, Name, and Price you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while(True):
      strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
      if(strUserInput.lower() == "exit"): break
      else: File.write(strUserInput + "\n")
  except Exception as e:
    print("Error: " + str(e))

def ReadAllFileData(File, Message="Contents of File"):
  try:
    print(Message)
    File.seek(0)
    print(File.read())
  except Exception as e:
    print("Error: " + str(e))

#I/O
try:
  objFile = open("Products.txt", "r+")
  ReadAllFileData(objFile, "Here is the current data:")
  WriteProductUserInput(objFile)
  ReadAllFileData(objFile, "Here is this data was saved:")
except FileNotFoundError as e:
     print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
  if(objFile != None):objFile.close()


'''
# I copy the code and run it in Pycharm to confirm it works.
# The appearance is crowded and i decide to use a menu like the homework before
# but limiting the options to present choice of seeing the catalogue, adding to the catalogue, and exiting.

# Data
objFile = None  # File Handle
strUserInput = None  # A string which holds user input


# Processing
# I create the class Catalogue Manager as the sub commands mainly affect the catalogue

class CatalogueManager(object):
    @staticmethod
    def Write(File):
        """Enters a new product id, name, and price to your catalogue"""

        try:
            print("Type in a Product Id, Name, and Price you want to add to the file")
            print("(Enter 'Exit' to quit!)")
            while (True):
                strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
                if (strUserInput.lower() == "exit"):
                    break
                else:
                    File.write(strUserInput + "\n")
        except Exception as e:
            print("Error: " + str(e))


    @staticmethod
    def Read(File, Message="Contents of File"):
        """Reads and prints the items in your catalogue."""
        try:
            print(Message)
            File.seek(0)
            print(File.read())
        except Exception as e:
            print("Error: " + str(e))

    @staticmethod
    def Option():
        """Display user options while interacting with catalogue."""
        print(
            """
            Catalogue Manager

            0 - Exit
            1 - Show Current Catalogue
            2 - Add to the Catalogue
            """
        )

# I/O
# I am then able in the main code to use my class and functions to execute the options
try:
    choice = None
    while choice != "0":

        CatalogueManager.Option()
        choice = input("Choice: ")
        print()
        # exit
        if choice == "0":
            print("Good-bye Y'all, See you real soon!")

        # list the catalogue
        elif choice == "1":
            objFile = open ("Products.txt", "r+")
            CatalogueManager.Read(objFile, "Item number, Item, Cost")

        # add item to catalogue
        elif choice == "2":
            objFile = open("Products.txt", "a+")
            CatalogueManager.Write(objFile)
            CatalogueManager.Read(objFile, "Here is where this data was saved:")# this line is technically not correct
            # it does not display the last entered data but rather all of the data in the file

except FileNotFoundError as e:
    print("Error: " + str(e) + "\n Please check the file name")#error handled when there is no file to write to;defunct with a+
except Exception as e:  # i think with looping the choices, it eliminates the except condition as strings do not manifest themselves
    print("Error: " + str(e))
finally:
    if (objFile != None):
        objFile.close()

# Wrapping the general outline for a function as outlined in the lesson did not lead it making this assignment easier.
# I thus did not break down the subparts for constructor, properties, and more field.  It did not add to the task.