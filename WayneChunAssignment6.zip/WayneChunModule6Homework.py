def AuthorHeader():
    print(
        """
        # -------------------------------------------------#
        # Title: Functions and Classes
        # Dev:   Wayne Chun
        # Date:  3 May 2018
        # ChangeLog: (Who, When, What)
        #   WChun, 3 May 2018 created functions starting with assignment 5
        #   program.
        #   WChun, 4 May 2018 fixed the inability to exit loop with while 
        #   command suggestion by Thomas Wright
        # 
        # -------------------------------------------------#

        """
    )
# End ProgramHeader function
# Call function
AuthorHeader()

def ProgramHeader():
    print(
        """
                         Coding with Function and Classes

        This program builds on Module 5 Working with Dictionaries.  
        It refines the code you created for managing a ToDo.txt file by
        using Functions and then grouping them into a Class. 
        
        
        """)
# End ProgramHeader function
# Call function
ProgramHeader()



#Data Code  aka  Global Variables
objFileName= "C:\_PythonClass\Todo.txt" #the working text file
strData =""                             #the string file
dicRow ={}                              #the dictionary row
lstTable = []                           #the list
x = 1
strChoice = None

#Processing Code aka Functions
class ListManager(object):
    """This Class contains methods to retrieve, manage, and store a list of paired items"""

    @staticmethod
    def ttdl(objFileName):
        """This function takes 2 items separated by (,)from a file and associates them into dictionary lines in a list."""
        with open(objFileName, "r") as workfile:   #use the with command to read the file from a global variable
                                                    #giving it a local variable of workfile
            for line in workfile:                   #act on each line now in a list
                strData = line.split(",")           #split each line at the comma
                dicRow = {strData[0].strip(): strData[1].strip()} #create a dictionary line with each list line
                lstTable.append(dicRow)             #for the global list variable, append each dictionary line
            return lstTable                         #return the list of dictionary lines

    @staticmethod
    def menu():
        """This function displays a choice menu for the user."""
        print ("""
            Menu of Options
            1)  Show current data
            2)  Add a new item.
            3)  Remove an existing item.
            4)  Save Data to File
            5)  Exit Program
            """)

    @staticmethod
    def option(number):
        """This function provide you the picklist options by number."""
        if (strChoice == '1'):
            print("Here is your honeydolist:",lstTable)  # show the dictionary list

        elif (strChoice == '2'):
            term = input("What task do you want me to add?: ") #request task from user
            i = len(lstTable)- 1  #check the length of the current list (adjust for position 0)and set it i a local variable
            while i >= 0:
                checkline = (lstTable[i]) #count the items down for position in the list with the assistance of length
                i = i - 1
                if term in checkline:  # check to see if task already exist
                    print("\nThat task already exists!") # if it does tell the user
                    break
            else:
                definition = input("\nWhat's the priority?: ")# if it does not get the priority of the new task
                dicRow = {term: definition}   #form the new dictionary row
                lstTable.append(dicRow)     # append it to your dictionary list
                print("\nYour new task to", term, "has been added.")  #let the user know what you added
                print("\n Here is your current list", lstTable)               #show user your new list

        elif (strChoice == '3'):
            term = input("What task do you want me to delete?: ")#request task to be deleted
            i = len(lstTable)- 1    #check the length of the current list (adjust for position 0)and set it i a local variable
            while i >= 0:
                checkline = (lstTable[i])   #count the items down for position in the list with the assistance of length
                i = i - 1
                if term in checkline:   # check to see if task already exist
                    del checkline[term] # delete the key and corresponding value
                    print("\nOkay, I deleted", term) # let the user know what you deleted
                    print ("\n Here is your current list", lstTable)     #show user your new list
                    break
            else:
                print("\nI can't do that!", term, "doesn't exist in the dictionary.") #if not in the list let user know

        elif (strChoice == '4'):            #write the data back into a text file
            localhandle = open(objFileName, "w")  #open the file in write mode
            for d in lstTable:          # assign d as a local variable for each item in the list
                for key, value in d.items(): # because d is a dictionary type use subcommand . items to pull key and value
                    localhandle.write(key + ',' + value + '\n') #you can now write each key and value on seperate lines
            print("Your saved list of dictionaries now looks like this:", lstTable)  #The save dictionary shows the pairs but in text file stored as
                                                                                     # key, value
            localhandle.close()

        elif (strChoice == '5'):
            print ("\n\nGoodbye!") #Greet user as they exit program

        else:
            print ("Please choose a numbered choice.") #handles other numbers put in to reroute back to choosing one of the 5

#Presentation Code aka Main Program
ListManager.ttdl(objFileName)  #call the file and convert text to dictionary line (ttdl)
while strChoice != '5':  # loop condition
    ListManager.menu()              #show user the menu of choices
    strChoice = str(input("Which option would you like to perform? [1 to 4] - ")) #take the users input
    ListManager.option(strChoice) #process the option chosen
