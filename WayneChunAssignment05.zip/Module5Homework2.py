# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Wayne Chun
# Date:  28 Apr 2018
# ChangeLog: (Who, When, What)
#   WChun, 28 Apr 2018, Created with help of starting template
#   from RRoot, Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file   "C:\_PythonClass\Todo.txt"
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection


# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
lstTable = [] #An empty honeydolist

objFileName = open("C:\\_PythonClass\\Todo.txt","r")
for line in objFileName:  # returns a string
    dicRow = {(line.split(",")[0]).strip(): (line.split(",")[1]).strip()}
    lstTable.append(dicRow)
objFileName.close()

# Step 2 - Display a menu of choices to the user

while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File Todo.txt
    5) Exit Program (Have you saved your changes?)
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

# Step 3 -Show the current items in the table
    if (strChoice == '1'):
        print("Here is your honeydolist:",lstTable)  # show the dictionary list
        continue

# Step 4 Adding another task
    elif (strChoice == '2'):
        term = input("What task do you want me to add?: ")
        i = len(lstTable)- 1
        while i >= 0:
            checkline = (lstTable[i])
            i = i - 1
            if term in checkline:
                print("\nThat task already exists!")
                break
        else:
            definition = input("\nWhat's the priority?: ")
            dicRow = {term: definition}
            lstTable.append(dicRow)
            print("\nYour new task to", term, "has been added.")
        continue

# Step 5 Remove an existing item
    elif (strChoice == '3'):
        term = input("What task do you want me to delete?: ")
        i = len(lstTable)- 1
        while i >= 0:
            checkline = (lstTable[i])
            i = i - 1
            if term in checkline:
                del checkline[term]
                print("\nOkay, I deleted", term)
                break
        else:
                print("\nI can't do that!", term, "doesn't exist in the dictionary.")
        continue

# Step 6 Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        i = len(lstTable) - 1
        while i >= 0:
            checkline = (lstTable[i])
            almost = str(checkline)
            print(almost)
            objFileName = open("C:\\_PythonClass\\Todo.txt", "a")
            objFileName.write(almost)
            i = i - 1
        print("Your data has been saved")
        objFileName.close()
        continue

# Step 7
    elif (strChoice == '5'):
        break  # and Exit the program